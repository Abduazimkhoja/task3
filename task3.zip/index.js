const secure = require("./secure");
const gameLogic = require("./gameLogic");
const prompts = require("prompts");

const moves = process.argv.slice(2);
if (
   new Set(moves).size !== moves.length ||
   moves.length % 2 === 0 ||
   moves.length < 3
) {
   console.error(
      "Error: The arguments must be odd in number, non-repeating and >= 3"
   );
   process.exit(1);
}

async function game() {
   const computerMove = moves[Math.floor(Math.random() * moves.length)];
   const key = secure.generateKey();
   const hmac = secure.getHMAC(key, computerMove);
	
   console.log("HMAC:", hmac);
   console.log("Available moves:");
   moves.forEach((move, index) => console.log(`${index + 1} - ${move}`));
   console.log("0 - exit");
   console.log("? - help");

   const response = await prompts({
      type: "text",
      name: "value",
      message: "Enter your move:",
      validate: (value) => {
         if (value === "?" || (+value > 0 && +value <= moves.length))
            return true;
         else
            return `Please enter a number between 0 and ${moves.length} or '?'`;
      },
   });

   if (response.value === 0) {
      process.exit(0);
   } else if (response.value === "?") {
      console.log(gameLogic.helpTable(moves));
      game();
   } else {
      const playerMove = moves[response.value - 1];
      console.log(`Your move: ${playerMove}`);
      console.log(`Computer move: ${computerMove}`);
      const result = gameLogic.whoWon(moves, computerMove, playerMove);
      console.log(
         `You ${
            result === "draw" ? "draw" : result === "player" ? "win!" : "lose!"
         }`
      );
      console.log(`HMAC key: ${key}`);
   }
}

game();
