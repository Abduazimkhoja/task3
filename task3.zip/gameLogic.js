const Table = require('cli-table3');

const chars = {
   top: "-",
   "top-mid": "+",
   "top-left": "+",
   "top-right": "+",
   bottom: "-",
   "bottom-mid": "+",
   "bottom-left": "+",
   "bottom-right": "+",
   left: "|",
   "left-mid": "+",
   mid: "-",
   "mid-mid": "+",
   right: "|",
   "right-mid": "+",
   middle: "|",
};


module.exports.whoWon = function (moves, computerMove, playerMove) {
   if (computerMove === playerMove) {
      return "draw";
   }
   const index = moves.indexOf(playerMove);
   const half = Math.floor(moves.length / 2);
   const shiftedMoves = [
      ...moves.slice(index + 1),
      ...moves.slice(0, index + 1),
   ];
   return shiftedMoves.indexOf(computerMove) < half ? "player" : "computer";
};

module.exports.helpTable = function (moves) {
	const table = new Table({
      head: ["v PC\\User >", ...moves],
      chars,
   });

   const len = (moves.length - 1) / 2;
   table.push(
      ...moves.map((item, index) => {
         let row = [];
         for (let i in moves) {
            if (+i === index) {
               row.push("Draw");
               continue;
            }
            if (+i <= index + len && i > index && index + len <= moves.length) {
               row.push("Win");
               continue;
            } else if (index + len < moves.length) {
               row.push("Lose");
               continue;
            }
            if (+i >= index - len && i < index) {
               row.push("Lose");
            } else row.push("Win");
         }
         return { [item]: row };
      })
   );
   return table.toString();
};
